# 快速使用指南

## 其他 OpenClaw 用户如何使用

### 1. 一键安装

```bash
# 进入 OpenClaw 技能目录
cd ~/.openclaw/skills

# 克隆仓库
git clone https://github.com/kejilion/news-voice-bot.git

# 运行安装脚本
cd news-voice-bot/skill
./install.sh
```

### 2. 配置

```bash
# 编辑配置文件
nano config.json

# 填入以下内容：
{
  "telegram": {
    "bot_token": "你的BotToken",
    "chat_id": "你的ChatID"
  }
}
```

### 3. 测试运行

```bash
# 手动运行一次测试
openclaw run news-voice

# 或直接运行
python3 news_voice_bot.py
```

### 4. 设置定时播报

```bash
# 查看定时设置帮助
openclaw run news-voice cron

# 方式1: 使用 crontab
crontab -e
# 添加: 0 9 * * * cd ~/.openclaw/skills/news-voice-bot && python3 news_voice_bot.py

# 方式2: 使用 systemd
sudo cp skill/systemd/* /etc/systemd/system/
sudo systemctl enable news-voice-bot.timer
sudo systemctl start news-voice-bot.timer
```

## 命令速查

```bash
openclaw run news-voice         # 运行播报
openclaw run news-voice config  # 编辑配置
openclaw run news-voice test    # 测试配置
openclaw run news-voice voice   # 查看可用语音
openclaw run news-voice help    # 查看帮助
```

## 文件位置

安装后文件位于：`~/.openclaw/skills/news-voice-bot/`

- `news_voice_bot.py` - 主程序
- `config.json` - 你的配置
- `skill/` - OpenClaw Skill 文件
