#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Daily News Voice Bot
自动抓取新闻并生成语音播报

Author: TechLion (@kejilion)
License: MIT
"""

import os
import sys
import json
import logging
import tempfile
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class NewsVoiceBot:
    """新闻语音播报机器人"""
    
    def __init__(self, config_path: str = "config.json"):
        """初始化机器人"""
        self.config = self._load_config(config_path)
        self.temp_dir = tempfile.mkdtemp()
        
    def _load_config(self, config_path: str) -> Dict:
        """加载配置文件"""
        if not os.path.exists(config_path):
            logger.error(f"配置文件不存在: {config_path}")
            logger.info("请复制 config.example.json 为 config.json 并填写配置")
            sys.exit(1)
            
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def fetch_google_news(self, lang: str = "zh-CN") -> List[Dict]:
        """
        抓取 Google News RSS
        
        Args:
            lang: 语言代码 (默认 zh-CN)
            
        Returns:
            新闻列表，每条包含 title, source, pub_date
        """
        logger.info("正在抓取 Google News...")
        
        rss_url = f"https://news.google.com/rss?hl={lang}&gl=CN&ceid=CN:zh"
        
        try:
            # 使用 curl 获取 RSS
            result = subprocess.run(
                ["curl", "-s", "--max-time", "30", rss_url],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                logger.error(f"抓取失败: {result.stderr}")
                return []
            
            # 解析 XML
            root = ET.fromstring(result.stdout)
            
            # 提取新闻
            news_list = []
            for item in root.findall(".//item")[:self.config.get("news_count", 10)]:
                title = item.find("title")
                source = item.find("source")
                pub_date = item.find("pubDate")
                
                if title is not None:
                    news_list.append({
                        "title": title.text,
                        "source": source.text if source is not None else "未知来源",
                        "pub_date": pub_date.text if pub_date is not None else ""
                    })
            
            logger.info(f"成功抓取 {len(news_list)} 条新闻")
            return news_list
            
        except Exception as e:
            logger.error(f"抓取新闻时出错: {e}")
            return []
    
    def generate_news_script(self, news_list: List[Dict]) -> str:
        """
        生成新闻播报脚本
        
        Args:
            news_list: 新闻列表
            
        Returns:
            播报文本
        """
        today = datetime.now().strftime("%m月%d日")
        weekday = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"][datetime.now().weekday()]
        
        script_parts = [
            f"今天是{today}，{weekday}，为您播报今日焦点新闻。",
            "",
            "以下是今日要闻：",
            ""
        ]
        
        for i, news in enumerate(news_list, 1):
            # 清理标题中的来源信息
            title = news["title"].split(" - ")[0]
            script_parts.append(f"{title}。")
        
        script_parts.extend([
            "",
            "以上就是今日新闻播报，感谢您的收听。"
        ])
        
        return "\n".join(script_parts)
    
    def generate_voice(self, text: str, output_path: str) -> bool:
        """
        使用 edge-tts 生成语音
        
        Args:
            text: 播报文本
            output_path: 输出文件路径
            
        Returns:
            是否成功
        """
        logger.info("正在生成语音...")
        
        voice = self.config.get("voice", "zh-CN-XiaoxiaoNeural")
        
        try:
            # 写入临时文本文件
            temp_text = os.path.join(self.temp_dir, "tts_text.txt")
            with open(temp_text, 'w', encoding='utf-8') as f:
                f.write(text)
            
            # 调用 edge-tts
            result = subprocess.run(
                ["edge-tts", "--voice", voice, "--file", temp_text, "--write-media", output_path],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                logger.info(f"语音生成成功: {output_path}")
                return True
            else:
                logger.error(f"语音生成失败: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"生成语音时出错: {e}")
            return False
    
    def send_to_telegram(self, text: str, voice_path: str) -> bool:
        """
        发送到 Telegram
        
        Args:
            text: 文字内容
            voice_path: 语音文件路径
            
        Returns:
            是否成功
        """
        logger.info("正在发送到 Telegram...")
        
        bot_token = self.config.get("telegram", {}).get("bot_token")
        chat_id = self.config.get("telegram", {}).get("chat_id")
        
        if not bot_token or not chat_id:
            logger.error("Telegram 配置不完整")
            return False
        
        try:
            # 发送文字
            text_cmd = [
                "curl", "-s", "-X", "POST",
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                "-d", f"chat_id={chat_id}",
                "-d", f"text={text}",
                "-d", "parse_mode=HTML"
            ]
            
            subprocess.run(text_cmd, capture_output=True)
            
            # 发送语音
            voice_cmd = [
                "curl", "-s", "-X", "POST",
                f"https://api.telegram.org/bot{bot_token}/sendVoice",
                "-F", f"chat_id={chat_id}",
                "-F", f"voice=@{voice_path}"
            ]
            
            result = subprocess.run(voice_cmd, capture_output=True)
            
            if result.returncode == 0:
                logger.info("发送成功！")
                return True
            else:
                logger.error(f"发送失败: {result.stderr}")
                return False
                
        except Exception as e:
            logger.error(f"发送时出错: {e}")
            return False
    
    def run(self):
        """运行完整流程"""
        logger.info("="*50)
        logger.info("开始每日新闻播报")
        logger.info("="*50)
        
        # 1. 抓取新闻
        news_list = self.fetch_google_news()
        if not news_list:
            logger.error("没有获取到新闻，退出")
            return False
        
        # 2. 生成播报脚本
        script = self.generate_news_script(news_list)
        
        # 3. 生成语音
        voice_path = os.path.join(self.temp_dir, "news_today.mp3")
        if not self.generate_voice(script, voice_path):
            return False
        
        # 4. 发送到 Telegram
        text_summary = self._generate_text_summary(news_list)
        self.send_to_telegram(text_summary, voice_path)
        
        logger.info("="*50)
        logger.info("播报完成！")
        logger.info("="*50)
        
        return True
    
    def _generate_text_summary(self, news_list: List[Dict]) -> str:
        """生成文字摘要"""
        lines = ["🎙️ <b>今日新闻播报</b>\n"]
        
        for i, news in enumerate(news_list[:10], 1):
            title = news["title"].split(" - ")[0]
            lines.append(f"{i}. {title}")
        
        return "\n".join(lines)


def main():
    """主函数"""
    bot = NewsVoiceBot()
    bot.run()


if __name__ == "__main__":
    main()
