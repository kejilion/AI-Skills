# News Voice Bot Skill for OpenClaw

🎙️ 自动新闻语音播报技能 - 每天自动抓取新闻并生成语音推送到 Telegram

## 功能

- 📰 自动抓取 Google News 中文头条
- 🎙️ 使用 Edge TTS 生成高质量中文语音
- 📱 自动推送到 Telegram
- ⏰ 支持定时每日播报

## 快速安装

在你的 OpenClaw 工作目录运行：

```bash
# 方式1：使用 git 安装
openclaw skills install https://github.com/kejilion/news-voice-bot.git

# 方式2：手动复制
ln -s /path/to/news-voice-bot/skill ~/.openclaw/skills/news-voice-bot
```

## 配置

1. 复制配置文件：

```bash
cp config.example.json config.json
```

2. 编辑 `config.json`：

```json
{
  "telegram": {
    "bot_token": "你的BotToken",
    "chat_id": "你的ChatID"
  },
  "voice": "zh-CN-XiaoxiaoNeural",
  "news_count": 10
}
```

### 获取 Telegram 配置

1. 找 @BotFather 创建机器人，获取 `bot_token`
2. 给机器人发消息，访问 `https://api.telegram.org/bot<Token>/getUpdates` 获取 `chat_id`

## 使用

### 手动播报

```bash
# 在项目目录运行
python3 news_voice_bot.py

# 或使用 OpenClaw
openclaw run news-vaily
```

### 设置定时播报（推荐）

**方式1：系统 crontab**

```bash
# 编辑 crontab
crontab -e

# 每天 9:00 播报
0 9 * * * cd ~/.openclaw/skills/news-voice-bot && python3 news_voice_bot.py >> /var/log/news-voice-bot.log 2>&1
```

**方式2：OpenClaw Cron（推荐）**

```bash
# 添加定时任务
openclaw cron add \
  --name "daily-news-voice" \
  --schedule "0 9 * * *" \
  --command "cd ~/.openclaw/skills/news-voice-bot && python3 news_voice_bot.py"
```

**方式3：使用 systemd**

```bash
# 安装 systemd 服务
sudo cp systemd/news-voice-bot.service /etc/systemd/system/
sudo cp systemd/news-voice-bot.timer /etc/systemd/system/

# 启用并启动
sudo systemctl daemon-reload
sudo systemctl enable news-voice-bot.timer
sudo systemctl start news-voice-bot.timer
```

## 自定义

### 修改播报时间

编辑 crontab 或 systemd timer 文件修改时间。

### 修改语音

在 `config.json` 中更改 `voice`：

- `zh-CN-XiaoxiaoNeural` - 女声（默认）
- `zh-CN-YunjianNeural` - 男声
- `zh-CN-YunxiNeural` - 男声（年轻）
- `zh-TW-HsiaoChenNeural` - 台湾女声
- `zh-HK-HiuMaanNeural` - 粤语女声

查看所有语音：

```bash
edge-tts --list-voices | grep zh-
```

### 修改新闻条数

在 `config.json` 中更改 `news_count`（默认10条）

## 文件结构

```
news-voice-bot/
├── news_voice_bot.py      # 主程序
├── config.example.json    # 配置示例
├── requirements.txt       # Python依赖
├── install.sh            # 安装脚本
├── SKILL.md              # 本文件
└── systemd/              # systemd服务文件
    ├── news-voice-bot.service
    └── news-voice-bot.timer
```

## 依赖

- Python 3.8+
- edge-tts
- curl

自动安装依赖：

```bash
pip3 install edge-tts
```

## 卸载

```bash
# 如果使用 crontab，先删除定时任务
crontab -e
# 删除对应的行

# 如果使用 systemd
sudo systemctl stop news-voice-bot.timer
sudo systemctl disable news-voice-bot.timer
sudo rm /etc/systemd/system/news-voice-bot.*

# 删除技能
rm -rf ~/.openclaw/skills/news-voice-bot
```

## 故障排除

### 问题：没有收到语音

1. 检查 config.json 配置是否正确
2. 运行 `python3 news_voice_bot.py` 看错误信息
3. 检查 edge-tts 是否安装：`edge-tts --help`

### 问题：抓不到新闻

1. 检查网络连接
2. 检查 curl 是否可用：`curl --version`
3. Google News 偶尔会被墙，可尝试使用代理

### 问题：Telegram 发送失败

1. 检查 bot_token 和 chat_id 是否正确
2. 确保机器人已启动，且已给机器人发送过消息
3. 检查网络连接

## 更新

```bash
cd ~/.openclaw/skills/news-voice-bot
git pull
```

## 开源协议

MIT License - 详见 LICENSE 文件

## 作者

- **TechLion** (@kejilion)
- GitHub: https://github.com/kejilion/news-voice-bot

## 致谢

- [edge-tts](https://github.com/rany2/edge-tts) - 语音合成
- Google News - 新闻数据
