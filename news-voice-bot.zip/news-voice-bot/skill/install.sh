#!/bin/bash
# OpenClaw Skill Install Script for News Voice Bot

set -e

echo "🎙️ 安装 News Voice Bot Skill..."

# 检查依赖
echo "📦 检查依赖..."

# 检查 Python
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: Python3 未安装"
    exit 1
fi

# 检查 pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ 错误: pip3 未安装"
    exit 1
fi

# 检查 curl
if ! command -v curl &> /dev/null; then
    echo "❌ 错误: curl 未安装"
    exit 1
fi

# 安装 Python 依赖
echo "📦 安装 Python 依赖..."
pip3 install --user edge-tts

# 创建配置
if [ ! -f "config.json" ]; then
    echo "📝 创建配置文件..."
    cp config.example.json config.json
    echo "⚠️  请编辑 config.json 填入你的 Telegram Bot Token 和 Chat ID"
fi

# 检查 OpenClaw 工作目录
if [ -n "$OPENCLAW_WORKSPACE" ]; then
    SKILL_DIR="$OPENCLAW_WORKSPACE/skills/news-voice-bot"
    mkdir -p "$OPENCLAW_WORKSPACE/skills"
    
    # 创建符号链接
    if [ ! -L "$SKILL_DIR" ]; then
        ln -sf "$(pwd)" "$SKILL_DIR"
        echo "✅ 已添加到 OpenClaw Skills"
    fi
fi

# 创建快捷命令
BIN_DIR="$HOME/.local/bin"
mkdir -p "$BIN_DIR"

cat > "$BIN_DIR/news-voice-bot" << 'EOF'
#!/bin/bash
cd "$(dirname "$(readlink -f "$0")")/.."
python3 news_voice_bot.py "$@"
EOF

chmod +x "$BIN_DIR/news-voice-bot"

echo ""
echo "✅ 安装完成！"
echo ""
echo "使用方法:"
echo "  1. 编辑配置文件: nano config.json"
echo "  2. 测试运行: python3 news_voice_bot.py"
echo "  3. 设置定时任务: crontab -e"
echo ""
echo "添加定时任务示例:"
echo "  0 9 * * * cd $(pwd) && python3 news_voice_bot.py"
echo ""
