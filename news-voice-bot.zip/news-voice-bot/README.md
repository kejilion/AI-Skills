# Daily News Voice Bot

🎙️ 自动抓取新闻并生成语音播报的机器人

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## 功能特点

- 📰 **自动抓取**：从 Google News 抓取最新中文新闻
- 🎙️ **语音播报**：使用 Edge TTS 生成高质量中文语音
- 📱 **自动推送**：支持 Telegram 自动推送
- ⏰ **定时任务**：可配置定时自动播报
- 🔧 **简单易用**：开箱即用，配置简单

## 安装

### 方式1：OpenClaw Skill 安装（推荐）

如果你使用 OpenClaw，可以直接作为 Skill 安装：

```bash
# 进入技能目录
cd ~/.openclaw/skills

# 克隆仓库
git clone https://github.com/kejilion/news-voice-bot.git

# 安装
cd news-voice-bot/skill
./install.sh

# 配置
cp config.example.json config.json
nano config.json  # 填入 Telegram Token

# 运行测试
openclaw run news-voice
```

### 方式2：普通安装

#### 1. 克隆仓库

```bash
git clone https://github.com/kejilion/news-voice-bot.git
cd news-voice-bot
```

#### 2. 安装依赖

```bash
pip install -r requirements.txt
```

#### 3. 安装 edge-tts

```bash
pip install edge-tts
```

## 配置

1. 复制配置文件模板：

```bash
cp config.example.json config.json
```

2. 编辑 `config.json`，填入你的配置：

```json
{
  "telegram": {
    "bot_token": "你的Bot Token",
    "chat_id": "你的Chat ID"
  },
  "voice": "zh-CN-XiaoxiaoNeural",
  "news_count": 10,
  "language": "zh-CN"
}
```

### 获取 Telegram Bot Token

1. 在 Telegram 中搜索 `@BotFather`
2. 发送 `/newbot` 创建新机器人
3. 按照提示设置名称，获得 Token

### 获取 Chat ID

1. 给机器人发送一条消息
2. 访问：`https://api.telegram.org/bot<你的Token>/getUpdates`
3. 查找 `"chat":{"id":` 后面的数字

## 使用

### 手动运行

```bash
python news_voice_bot.py
```

### 设置定时任务（Linux/macOS）

编辑 crontab：

```bash
crontab -e
```

添加每天 9:00 自动播报：

```bash
0 9 * * * cd /path/to/news-voice-bot && python news_voice_bot.py >> /var/log/news-voice-bot.log 2>&1
```

### 使用 systemd（Linux）

创建服务文件：

```bash
sudo nano /etc/systemd/system/news-voice-bot.service
```

写入内容：

```ini
[Unit]
Description=Daily News Voice Bot
After=network.target

[Service]
Type=oneshot
User=your-username
WorkingDirectory=/path/to/news-voice-bot
ExecStart=/usr/bin/python3 /path/to/news-voice-bot/news_voice_bot.py

[Install]
WantedBy=multi-user.target
```

启用定时器（每天 9:00）：

```bash
sudo nano /etc/systemd/system/news-voice-bot.timer
```

```ini
[Unit]
Description=Run News Voice Bot daily at 9:00

[Timer]
OnCalendar=*-*-* 09:00:00
Persistent=true

[Install]
WantedBy=timers.target
```

启动：

```bash
sudo systemctl daemon-reload
sudo systemctl enable news-voice-bot.timer
sudo systemctl start news-voice-bot.timer
```

## 支持的语音

默认使用 `zh-CN-XiaoxiaoNeural`（中文女声）

其他可选中文语音：
- `zh-CN-XiaoyiNeural`（女声）
- `zh-CN-YunjianNeural`（男声）
- `zh-CN-YunxiNeural`（男声）
- `zh-CN-YunxiaNeural`（男声）
- `zh-TW-HsiaoChenNeural`（台湾女声）
- `zh-HK-HiuMaanNeural`（粤语女声）

查看所有可用语音：

```bash
edge-tts --list-voices
```

## 自定义开发

### 修改新闻源

编辑 `news_voice_bot.py` 中的 `fetch_google_news()` 方法，可以接入其他 RSS 源：

```python
def fetch_custom_news(self) -> List[Dict]:
    # 自定义新闻抓取逻辑
    pass
```

### 修改播报风格

编辑 `generate_news_script()` 方法自定义播报文本模板。

## Docker 部署

```bash
docker build -t news-voice-bot .
docker run -v $(pwd)/config.json:/app/config.json news-voice-bot
```

## 项目结构

```
news-voice-bot/
├── news_voice_bot.py      # 主程序
├── config.example.json    # 配置示例
├── config.json           # 配置文件（需自己创建）
├── requirements.txt      # Python 依赖
├── Dockerfile           # Docker 构建文件
├── .gitignore          # Git 忽略文件
└── README.md           # 说明文档
```

## 许可证

[MIT License](LICENSE)

## 贡献

欢迎提交 Issue 和 Pull Request！

## 作者

- **TechLion** - [@kejilion](https://github.com/kejilion)

## 致谢

- [edge-tts](https://github.com/rany2/edge-tts) - 微软 Edge TTS 的 Python 封装
- Google News - 新闻数据源
